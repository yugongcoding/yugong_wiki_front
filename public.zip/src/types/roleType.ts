/* eslint-disable no-shadow */
export enum RoleType {
  admin = 'admin',
  user = 'user',
}
