export interface MockParams {
  url: string;
  type: string;
  body: string;
}
