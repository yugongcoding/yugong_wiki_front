<template>
  <svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" fit="" height="1em" width="1em" preserveAspectRatio="xMidYMid meet" focusable="false"><g id="ann1.Base基础/1.icon图标/1.-action/Insert-Up-" stroke-width="1" fill-rule="evenodd"><g id="ann编组" transform="translate(1.8 2.1)" fill-rule="nonzero"><path d="M12.383.513a.616.616 0 0 1 .1 1.223l-.1.008h-3.43a.616.616 0 0 1-.1-1.223l.1-.008h3.43zm0 5.128a.616.616 0 0 1 .1 1.223l-.1.008h-3.43a.616.616 0 0 1-.1-1.223l.1-.008h3.43zM3.19 0c.307 0 .561.196.61.453l.007.088v1.817l1.8.001c.313 0 .567.275.567.615 0 .306-.205.56-.475.608l-.092.008-1.8-.001v2.024c0 .299-.276.54-.617.54-.307 0-.562-.195-.61-.453l-.007-.087-.001-2.024H.567C.254 3.59 0 3.315 0 2.975c0-.306.206-.56.475-.607l.092-.008 2.005-.001V.541C2.573.242 2.85 0 3.19 0zm9.193 10.77a.616.616 0 0 1 .1 1.222l-.1.008H.845a.616.616 0 0 1-.1-1.223l.1-.008h11.538z" id="ann形状结合"></path></g></g></svg>
</template>


