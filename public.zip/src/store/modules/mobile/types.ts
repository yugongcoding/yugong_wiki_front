export interface MobileState {
  asideWidth: number,
  placement: string;
  showManageCollapse: boolean;
  showCollapse: boolean;
  splitInit: string;
  articleMenuNodeTooltipPlacement: string;
  hideAfter: number;
  showAnchor: boolean;
  is_pc: boolean;
}
