export default {
  'http.error.TokenExpire': '登录过期，请重新登录',
  'http.error.UserNotFound': '用户不存在',
  'http.error.UserAlreadyExist': '用户已存在',
  'http.error.InvalidParameter': '无效的请求参数',
  'http.error.InternalError': '服务器错误',
  'http.error.ErrorPassword': '账号或密码错误',
};
