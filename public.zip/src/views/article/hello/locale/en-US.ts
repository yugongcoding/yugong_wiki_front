export default {
  'menu.cloud.hello': 'Hello World',
};
