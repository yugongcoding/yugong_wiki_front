<template>
  article
</template>

<script lang="ts" setup></script>

<style scoped lang="less"></style>
