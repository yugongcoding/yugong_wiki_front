export default {
  'space.team.createTeamSpace': '创建团队空间',
  'space.book.createBookSpace': '创建知识空间',
  'space.team.teamSpace': '团队空间',
  'space.book.bookSpace': '知识空间'
};
