export default {
  'space.team.createTeamSpace': 'Create Team Space',
  'space.book.createBookSpace': 'Create Book Space',
  'space.team.teamSpace': 'Knowledge Base Space',
  'space.book.bookSpace': 'Knowledge Base Space'
};
