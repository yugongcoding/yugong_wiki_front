<template>
  <router-view />
</template>

<script lang="ts" setup></script>

<style scoped lang="less">
@import '@/assets/style/menu.less';
</style>
