export default {
  'menu.result.success': '成功页',
  'success.result.title': '提交结果页用于反馈一系列操作任务的处理结果。',
  'menu.result.messageSuccess': '辅导流程提交成功！',
  'menu.result.messageEnd': '辅导流程已提交结束！',
  'menu.btn.submit': '启动新的辅导',
  'menu.btn.cancel': '取消',
  'menu.line.process': '当前进度',
};
