export default {
  'menu.result.success': 'Success',
  'success.result.title':
    'The submission result page displays the processing results of a series of operation tasks.',
  'menu.result.messageSuccess':
    'The coaching process is submitted successfully',
  'menu.btn.submit': 'Start',
  'menu.btn.cancel': 'Cancel',
  'menu.line.process': 'Current progress',
  'menu.result.messageEnd': 'The coaching process has been submitted',
};
