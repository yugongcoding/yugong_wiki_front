export default {
  'menu.result.error': '失败页',
  'error.result.title': '提交结果页用于反馈一系列操作任务的处理结果。',
  'menu.result.messageError': '辅导流程提交失败',
  'error.result.home': '回到首页',
};
