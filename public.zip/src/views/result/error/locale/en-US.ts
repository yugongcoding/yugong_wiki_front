export default {
  'menu.result.error': 'Error',
  'error.result.title':
    'The submission result page displays the processing results of a series of operation tasks',
  'menu.result.messageError': 'Failed to submit the coaching process',
  'error.result.home': 'Back',
};
