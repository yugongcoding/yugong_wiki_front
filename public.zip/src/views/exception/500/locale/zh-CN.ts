export default {
  'menu.exception.500': '500',
  'exception.result.500.description': '抱歉，服务器出了点问题～',
  'exception.result.500.back': '返回',
  'exception.result.permissions.500': '请查看网络连接情况，尝试刷新页面',
};
