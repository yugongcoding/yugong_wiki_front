export default {
  'menu.exception.500': '500',
  'exception.result.500.description': 'Internal server error',
  'exception.result.500.back': 'Back',
  'exception.result.permissions.500':
    'Check the network connection and try to refresh the page.',
};
