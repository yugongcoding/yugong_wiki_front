export default {
  'menu.exception.403': '403',
  'exception.result.403.description':
    'Access to this resource on the server is denied.',
  'exception.result.403.back': 'Back',
  'exception.result.permissions.403':
    'Contact the administrator to apply for the permission.。',
};
