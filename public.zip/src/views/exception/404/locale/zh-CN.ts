export default {
  'menu.exception.404': '404',
  'exception.result.404.description': '抱歉，页面不见了～',
  'exception.result.404.retry': '重试',
  'exception.result.404.back': '返回',
  'exception.result.permissions.404': '请查看网络连接情况，尝试刷新页面',
};
