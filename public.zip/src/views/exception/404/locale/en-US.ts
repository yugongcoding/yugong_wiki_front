export default {
  'menu.exception.404': '404',
  'exception.result.404.description': 'Whoops, this page is gone.',
  'exception.result.404.retry': 'Retry',
  'exception.result.404.back': 'Back',
  'exception.result.permissions.404':
    'Check the network connection and try to refresh the page.',
};
