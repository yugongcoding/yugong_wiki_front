module.exports = {
  plugins: ['@vue/babel-plugin-jsx'],
};
